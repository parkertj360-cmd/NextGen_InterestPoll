# NextGen Success Guide - GitHub Pages Deployment Instructions

## 🚀 Quick Deployment (2 Minutes)

Follow these simple steps to get your site live permanently on GitHub Pages.

---

## Step 1: Upload Files to GitHub

1. Go to your repository: **https://github.com/parkertj360-cmd/NextGen_InterestPoll**

2. Click the **"Add file"** button, then select **"Upload files"**

3. Drag and drop these files from the `deployment-files` folder:
   - `index.html`
   - The entire `assets` folder

4. Scroll down and click **"Commit changes"**

---

## Step 2: Enable GitHub Pages

1. In your repository, click **"Settings"** (top menu)

2. In the left sidebar, click **"Pages"**

3. Under **"Source"**, select:
   - Branch: **main**
   - Folder: **/ (root)**

4. Click **"Save"**

5. Wait 1-2 minutes for deployment

---

## Step 3: Get Your Live URL

After a minute or two, refresh the Pages settings page. You'll see:

**"Your site is live at: https://parkertj360-cmd.github.io/NextGen_InterestPoll/"**

That's your permanent, free URL! ✅

---

## 🎯 Your Permanent Link

Once deployed, your site will be available at:

**https://parkertj360-cmd.github.io/NextGen_InterestPoll/**

This link:
- ✅ Works forever (free, no expiration)
- ✅ Has SSL/HTTPS security
- ✅ Loads fast globally
- ✅ Can be updated anytime by uploading new files

---

## 📱 Next Steps After Deployment

### 1. Generate a New QR Code
Once your site is live, create a QR code for the permanent URL:
- Use a free tool like **qr-code-generator.com**
- Input: `https://parkertj360-cmd.github.io/NextGen_InterestPoll/`
- Download and use on flyers, social media, etc.

### 2. Optional: Add a Custom Domain
If you want a branded URL like `nextgen.yourdomain.com`:
1. Buy a domain (Namecheap, Google Domains, etc.)
2. In GitHub Pages settings, add your custom domain
3. Update your DNS records (GitHub provides instructions)

### 3. Update the Google Sheets Integration
The app already has a Google Sheets URL configured in the code. Make sure:
- Your Google Apps Script is deployed and accepting data
- The URL in the app matches your script URL

---

## 🔄 How to Update Your Site Later

Whenever you want to make changes:
1. Make updates to your local files
2. Go to GitHub repository
3. Click "Upload files" and replace the old files
4. Changes go live in 1-2 minutes automatically

---

## 📊 Tracking & Analytics

Consider adding:
- **Google Analytics** - Track visitor behavior
- **Meta Pixel** - Track conversions for ads
- **Hotjar** - See how users interact with the app

These can be added by inserting tracking codes in the `index.html` file.

---

## ⚠️ Important Notes

### API Key Reminder
The app currently uses a **placeholder Gemini API key**. For full AI functionality:
1. Get your free key at: https://aistudio.google.com/apikey
2. Update the `.env.local` file in your source code
3. Rebuild with `npm run build`
4. Re-upload the new `dist` files to GitHub

### File Structure
The deployment files are already optimized and built. You're uploading the **production version** that's ready to run.

---

## 💡 Pro Tips

**Share Your Link Everywhere:**
- Add to email signatures
- Post on social media
- Include in text message campaigns
- Print on business cards
- Add to your website footer

**Monitor Performance:**
- GitHub provides basic traffic stats in the repository Insights
- Check "Traffic" to see page views and visitor sources

**Keep It Updated:**
- Regularly update content to keep users engaged
- Add new testimonials as you collect them
- Refresh career pathway information seasonally

---

## 🆘 Troubleshooting

**Site not loading?**
- Wait 2-3 minutes after enabling Pages
- Hard refresh your browser (Ctrl+Shift+R or Cmd+Shift+R)
- Check that files are in the root directory, not in a subfolder

**404 Error?**
- Make sure `index.html` is in the root of your repository
- Verify GitHub Pages is enabled and set to "main" branch

**Styling looks broken?**
- Ensure the `assets` folder uploaded correctly
- Check that the folder structure matches: `assets/index-CM0aKvuN.js`

---

## 📞 Need Help?

If you run into issues:
1. Check GitHub's Pages documentation: https://docs.github.com/pages
2. Verify all files uploaded correctly
3. Make sure Pages is enabled in Settings

---

**You're about to have a permanent, professional recruitment tool live on the web. Let's get it done!** 🚀
